# La meva pròpia web

A Pen created on CodePen.

Original URL: [https://codepen.io/Jan-Moreno-Rif-/pen/dPbBgbN](https://codepen.io/Jan-Moreno-Rif-/pen/dPbBgbN).

